int main(void)
{
	return (int)10ui64;
}
